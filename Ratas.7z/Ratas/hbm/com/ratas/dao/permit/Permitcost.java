package com.ratas.dao.permit;

import java.util.Date;


/**
 * Permitcost entity. @author MyEclipse Persistence Tools
 */

public class Permitcost  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String vehicletype;
     private String cost;
     private Date validity;


    // Constructors

    /** default constructor */
    public Permitcost() {
    }

    
    /** full constructor */
    public Permitcost(String vehicletype, String cost, Date validity) {
        this.vehicletype = vehicletype;
        this.cost = cost;
        this.validity = validity;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getVehicletype() {
        return this.vehicletype;
    }
    
    public void setVehicletype(String vehicletype) {
        this.vehicletype = vehicletype;
    }

    public String getCost() {
        return this.cost;
    }
    
    public void setCost(String cost) {
        this.cost = cost;
    }

    public Date getValidity() {
        return this.validity;
    }
    
    public void setValidity(Date validity) {
        this.validity = validity;
    }
   








}