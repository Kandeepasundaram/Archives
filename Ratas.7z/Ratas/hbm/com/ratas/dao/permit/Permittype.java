package com.ratas.dao.permit;



/**
 * Permittype entity. @author MyEclipse Persistence Tools
 */

public class Permittype  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String permittype;


    // Constructors

    /** default constructor */
    public Permittype() {
    }

    
    /** full constructor */
    public Permittype(String permittype) {
        this.permittype = permittype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getPermittype() {
        return this.permittype;
    }
    
    public void setPermittype(String permittype) {
        this.permittype = permittype;
    }
   








}