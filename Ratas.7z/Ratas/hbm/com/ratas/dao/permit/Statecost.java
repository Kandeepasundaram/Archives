package com.ratas.dao.permit;



/**
 * Statecost entity. @author MyEclipse Persistence Tools
 */

public class Statecost  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String statename;
     private String cost;


    // Constructors

    /** default constructor */
    public Statecost() {
    }

    
    /** full constructor */
    public Statecost(String statename, String cost) {
        this.statename = statename;
        this.cost = cost;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getStatename() {
        return this.statename;
    }
    
    public void setStatename(String statename) {
        this.statename = statename;
    }

    public String getCost() {
        return this.cost;
    }
    
    public void setCost(String cost) {
        this.cost = cost;
    }
   








}