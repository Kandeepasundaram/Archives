package com.ratas.dao.permit;

import com.ratas.dao.commons.Zones;
import com.ratas.dao.registration.Vehiclemain;
import java.util.Date;


/**
 * Permitmain entity. @author MyEclipse Persistence Tools
 */

public class Permitmain  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String userid;
     private Date permitvalidity;
     private Permittype permittype;
     private Zones zoneid;
     private Vehiclemain vehicleid;


    // Constructors

    /** default constructor */
    public Permitmain() {
    }

    
    /** full constructor */
    public Permitmain(String userid, Date permitvalidity, Permittype permittype, Zones zoneid, Vehiclemain vehicleid) {
        this.userid = userid;
        this.permitvalidity = permitvalidity;
        this.permittype = permittype;
        this.zoneid = zoneid;
        this.vehicleid = vehicleid;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getUserid() {
        return this.userid;
    }
    
    public void setUserid(String userid) {
        this.userid = userid;
    }

    public Date getPermitvalidity() {
        return this.permitvalidity;
    }
    
    public void setPermitvalidity(Date permitvalidity) {
        this.permitvalidity = permitvalidity;
    }

    public Permittype getPermittype() {
        return this.permittype;
    }
    
    public void setPermittype(Permittype permittype) {
        this.permittype = permittype;
    }

    public Zones getZoneid() {
        return this.zoneid;
    }
    
    public void setZoneid(Zones zoneid) {
        this.zoneid = zoneid;
    }

    public Vehiclemain getVehicleid() {
        return this.vehicleid;
    }
    
    public void setVehicleid(Vehiclemain vehicleid) {
        this.vehicleid = vehicleid;
    }
   








}