package com.ratas.dao.commons;

import java.util.Date;


/**
 * Users entity. @author MyEclipse Persistence Tools
 */

public class Users  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String username;
     private String password;
     private String question;
     private String answer;
     private String authorized;
     private Date doa;
     private Personal personal;
     private UserType usertype;
     private Zones zone;


    // Constructors

    /** default constructor */
    public Users() {
    }

    
    /** full constructor */
    public Users(String username, String password, String question, String answer, String authorized, Date doa, Personal personal, UserType usertype, Zones zone) {
        this.username = username;
        this.password = password;
        this.question = question;
        this.answer = answer;
        this.authorized = authorized;
        this.doa = doa;
        this.personal = personal;
        this.usertype = usertype;
        this.zone = zone;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getUsername() {
        return this.username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }

    public String getQuestion() {
        return this.question;
    }
    
    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return this.answer;
    }
    
    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getAuthorized() {
        return this.authorized;
    }
    
    public void setAuthorized(String authorized) {
        this.authorized = authorized;
    }

    public Date getDoa() {
        return this.doa;
    }
    
    public void setDoa(Date doa) {
        this.doa = doa;
    }

    public Personal getPersonal() {
        return this.personal;
    }
    
    public void setPersonal(Personal personal) {
        this.personal = personal;
    }

    public UserType getUsertype() {
        return this.usertype;
    }
    
    public void setUsertype(UserType usertype) {
        this.usertype = usertype;
    }

    public Zones getZone() {
        return this.zone;
    }
    
    public void setZone(Zones zone) {
        this.zone = zone;
    }

}