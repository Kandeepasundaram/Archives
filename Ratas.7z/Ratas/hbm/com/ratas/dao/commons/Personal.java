package com.ratas.dao.commons;

import java.util.Date;


/**
 * Personal entity. @author MyEclipse Persistence Tools
 */

public class Personal  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String firstname;
     private String secondname;
     private Date dateofbirth;
     private String permanentaddress1;
     private String permanentaddress2;
     private String contactaddress1;
     private String contactaddress2;
     private String phone;
     private String mobile;
     private String email;
     private Photos photo;
     private Users userid;


    // Constructors

    /** default constructor */
    public Personal() {
    }

    
    /** full constructor */
    public Personal(String firstname, String secondname, Date dateofbirth, String permanentaddress1, String permanentaddress2, String contactaddress1, String contactaddress2, String phone, String mobile, String email, Photos photo, Users userid) {
        this.firstname = firstname;
        this.secondname = secondname;
        this.dateofbirth = dateofbirth;
        this.permanentaddress1 = permanentaddress1;
        this.permanentaddress2 = permanentaddress2;
        this.contactaddress1 = contactaddress1;
        this.contactaddress2 = contactaddress2;
        this.phone = phone;
        this.mobile = mobile;
        this.email = email;
        this.photo = photo;
        this.userid = userid;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getFirstname() {
        return this.firstname;
    }
    
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSecondname() {
        return this.secondname;
    }
    
    public void setSecondname(String secondname) {
        this.secondname = secondname;
    }

    public Date getDateofbirth() {
        return this.dateofbirth;
    }
    
    public void setDateofbirth(Date dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getPermanentaddress1() {
        return this.permanentaddress1;
    }
    
    public void setPermanentaddress1(String permanentaddress1) {
        this.permanentaddress1 = permanentaddress1;
    }

    public String getPermanentaddress2() {
        return this.permanentaddress2;
    }
    
    public void setPermanentaddress2(String permanentaddress2) {
        this.permanentaddress2 = permanentaddress2;
    }

    public String getContactaddress1() {
        return this.contactaddress1;
    }
    
    public void setContactaddress1(String contactaddress1) {
        this.contactaddress1 = contactaddress1;
    }

    public String getContactaddress2() {
        return this.contactaddress2;
    }
    
    public void setContactaddress2(String contactaddress2) {
        this.contactaddress2 = contactaddress2;
    }

    public String getPhone() {
        return this.phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobile() {
        return this.mobile;
    }
    
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public Photos getPhoto() {
        return this.photo;
    }
    
    public void setPhoto(Photos photo) {
        this.photo = photo;
    }

    public Users getUserid() {
        return this.userid;
    }
    
    public void setUserid(Users userid) {
        this.userid = userid;
    }
   








}