package com.ratas.dao.commons;

import java.sql.Blob;


/**
 * Photos entity. @author MyEclipse Persistence Tools
 */

public class Photos  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private Blob photo;


    // Constructors

    /** default constructor */
    public Photos() {
    }

    
    /** full constructor */
    public Photos(Blob photo) {
        this.photo = photo;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public Blob getPhoto() {
        return this.photo;
    }
    
    public void setPhoto(Blob photo) {
        this.photo = photo;
    }
   








}