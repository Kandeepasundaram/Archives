package com.ratas.dao.commons;

import java.util.Date;


/**
 * Complaint entity. @author MyEclipse Persistence Tools
 */

public class Complaint  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String status;
     private Date date;
     private String zone;
     private Complaintcategory category;


    // Constructors

    /** default constructor */
    public Complaint() {
    }

    
    /** full constructor */
    public Complaint(String status, Date date, String zone, Complaintcategory category) {
        this.status = status;
        this.date = date;
        this.zone = zone;
        this.category = category;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }

    public String getZone() {
        return this.zone;
    }
    
    public void setZone(String zone) {
        this.zone = zone;
    }

    public Complaintcategory getCategory() {
        return this.category;
    }
    
    public void setCategory(Complaintcategory category) {
        this.category = category;
    }
   








}