package com.ratas.dao.commons;



/**
 * UserType entity. @author MyEclipse Persistence Tools
 */

public class UserType  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String usertype;


    // Constructors

    /** default constructor */
    public UserType() {
    }

    
    /** full constructor */
    public UserType(String usertype) {
        this.usertype = usertype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getUsertype() {
        return this.usertype;
    }
    
    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }
   








}