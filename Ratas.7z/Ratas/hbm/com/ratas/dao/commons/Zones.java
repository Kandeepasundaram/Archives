package com.ratas.dao.commons;



/**
 * Zones entity. @author MyEclipse Persistence Tools
 */

public class Zones  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String zone;
     private String district;
     private String state;
     private String rtocode;
     private String noofappointments;


    // Constructors

    /** default constructor */
    public Zones() {
    }

    
    /** full constructor */
    public Zones(String zone, String district, String state, String rtocode, String noofappointments) {
        this.zone = zone;
        this.district = district;
        this.state = state;
        this.rtocode = rtocode;
        this.noofappointments = noofappointments;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getZone() {
        return this.zone;
    }
    
    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getDistrict() {
        return this.district;
    }
    
    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return this.state;
    }
    
    public void setState(String state) {
        this.state = state;
    }

    public String getRtocode() {
        return this.rtocode;
    }
    
    public void setRtocode(String rtocode) {
        this.rtocode = rtocode;
    }

    public String getNoofappointments() {
        return this.noofappointments;
    }
    
    public void setNoofappointments(String noofappointments) {
        this.noofappointments = noofappointments;
    }
   








}