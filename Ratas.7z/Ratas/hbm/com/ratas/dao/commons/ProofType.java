package com.ratas.dao.commons;



/**
 * ProofType entity. @author MyEclipse Persistence Tools
 */

public class ProofType  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String prooftype;


    // Constructors

    /** default constructor */
    public ProofType() {
    }

    
    /** full constructor */
    public ProofType(String prooftype) {
        this.prooftype = prooftype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getProoftype() {
        return this.prooftype;
    }
    
    public void setProoftype(String prooftype) {
        this.prooftype = prooftype;
    }
   








}