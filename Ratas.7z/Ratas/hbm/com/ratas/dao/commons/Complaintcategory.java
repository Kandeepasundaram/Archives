package com.ratas.dao.commons;



/**
 * Complaintcategory entity. @author MyEclipse Persistence Tools
 */

public class Complaintcategory  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String category;


    // Constructors

    /** default constructor */
    public Complaintcategory() {
    }

    
    /** full constructor */
    public Complaintcategory(String category) {
        this.category = category;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getCategory() {
        return this.category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
   








}