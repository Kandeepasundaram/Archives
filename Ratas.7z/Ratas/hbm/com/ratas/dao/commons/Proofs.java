package com.ratas.dao.commons;



/**
 * Proofs entity. @author MyEclipse Persistence Tools
 */

public class Proofs  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String proofname;
     private ProofType prooftype;


    // Constructors

    /** default constructor */
    public Proofs() {
    }

    
    /** full constructor */
    public Proofs(String proofname, ProofType prooftype) {
        this.proofname = proofname;
        this.prooftype = prooftype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getProofname() {
        return this.proofname;
    }
    
    public void setProofname(String proofname) {
        this.proofname = proofname;
    }

    public ProofType getProoftype() {
        return this.prooftype;
    }
    
    public void setProoftype(ProofType prooftype) {
        this.prooftype = prooftype;
    }
   








}