package com.ratas.dao.commons;

import java.util.Date;


/**
 * Appointments entity. @author MyEclipse Persistence Tools
 */

public class Appointments  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String status;
     private String typeofoperation;
     private Date date;
     private String zone;
     private Users userid;


    // Constructors

    /** default constructor */
    public Appointments() {
    }

    
    /** full constructor */
    public Appointments(String status, String typeofoperation, Date date, String zone, Users userid) {
        this.status = status;
        this.typeofoperation = typeofoperation;
        this.date = date;
        this.zone = zone;
        this.userid = userid;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }

    public String getTypeofoperation() {
        return this.typeofoperation;
    }
    
    public void setTypeofoperation(String typeofoperation) {
        this.typeofoperation = typeofoperation;
    }

    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }

    public String getZone() {
        return this.zone;
    }
    
    public void setZone(String zone) {
        this.zone = zone;
    }

    public Users getUserid() {
        return this.userid;
    }
    
    public void setUserid(Users userid) {
        this.userid = userid;
    }
   








}