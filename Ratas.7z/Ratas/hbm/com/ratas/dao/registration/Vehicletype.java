package com.ratas.dao.registration;



/**
 * Vehicletype entity. @author MyEclipse Persistence Tools
 */

public class Vehicletype  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String regno;


    // Constructors

    /** default constructor */
    public Vehicletype() {
    }

    
    /** full constructor */
    public Vehicletype(String regno) {
        this.regno = regno;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getRegno() {
        return this.regno;
    }
    
    public void setRegno(String regno) {
        this.regno = regno;
    }
   








}