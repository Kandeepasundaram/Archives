package com.ratas.dao.registration;



/**
 * Vehiclehistorytype entity. @author MyEclipse Persistence Tools
 */

public class Vehiclehistorytype  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String historytype;


    // Constructors

    /** default constructor */
    public Vehiclehistorytype() {
    }

    
    /** full constructor */
    public Vehiclehistorytype(String historytype) {
        this.historytype = historytype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getHistorytype() {
        return this.historytype;
    }
    
    public void setHistorytype(String historytype) {
        this.historytype = historytype;
    }
   








}