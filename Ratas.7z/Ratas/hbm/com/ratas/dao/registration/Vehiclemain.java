package com.ratas.dao.registration;

import java.util.Date;


/**
 * Vehiclemain entity. @author MyEclipse Persistence Tools
 */

public class Vehiclemain  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String regno;
     private Date dateofreg;
     private String vehicleid;
     private boolean hypo;
     private Vehicletype vehicletype;
     private Vehiclecategory vehiclecategory;


    // Constructors

    /** default constructor */
    public Vehiclemain() {
    }

    
    /** full constructor */
    public Vehiclemain(String regno, Date dateofreg, String vehicleid, boolean hypo, Vehicletype vehicletype, Vehiclecategory vehiclecategory) {
        this.regno = regno;
        this.dateofreg = dateofreg;
        this.vehicleid = vehicleid;
        this.hypo = hypo;
        this.vehicletype = vehicletype;
        this.vehiclecategory = vehiclecategory;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getRegno() {
        return this.regno;
    }
    
    public void setRegno(String regno) {
        this.regno = regno;
    }

    public Date getDateofreg() {
        return this.dateofreg;
    }
    
    public void setDateofreg(Date dateofreg) {
        this.dateofreg = dateofreg;
    }

    public String getVehicleid() {
        return this.vehicleid;
    }
    
    public void setVehicleid(String vehicleid) {
        this.vehicleid = vehicleid;
    }

    public boolean getHypo() {
        return this.hypo;
    }
    
    public void setHypo(boolean hypo) {
        this.hypo = hypo;
    }

    public Vehicletype getVehicletype() {
        return this.vehicletype;
    }
    
    public void setVehicletype(Vehicletype vehicletype) {
        this.vehicletype = vehicletype;
    }

    public Vehiclecategory getVehiclecategory() {
        return this.vehiclecategory;
    }
    
    public void setVehiclecategory(Vehiclecategory vehiclecategory) {
        this.vehiclecategory = vehiclecategory;
    }
   








}