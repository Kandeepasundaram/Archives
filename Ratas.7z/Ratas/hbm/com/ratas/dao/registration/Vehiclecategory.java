package com.ratas.dao.registration;



/**
 * Vehiclecategory entity. @author MyEclipse Persistence Tools
 */

public class Vehiclecategory  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String vehiclecategory;


    // Constructors

    /** default constructor */
    public Vehiclecategory() {
    }

    
    /** full constructor */
    public Vehiclecategory(String vehiclecategory) {
        this.vehiclecategory = vehiclecategory;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getVehiclecategory() {
        return this.vehiclecategory;
    }
    
    public void setVehiclecategory(String vehiclecategory) {
        this.vehiclecategory = vehiclecategory;
    }
   








}