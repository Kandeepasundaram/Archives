package com.ratas.dao.registration;



/**
 * Hypodetails entity. @author MyEclipse Persistence Tools
 */

public class Hypodetails  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private Vehiclemain vehicleid;


    // Constructors

    /** default constructor */
    public Hypodetails() {
    }

    
    /** full constructor */
    public Hypodetails(Vehiclemain vehicleid) {
        this.vehicleid = vehicleid;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public Vehiclemain getVehicleid() {
        return this.vehicleid;
    }
    
    public void setVehicleid(Vehiclemain vehicleid) {
        this.vehicleid = vehicleid;
    }
   








}