package com.ratas.dao.registration;



/**
 * Vehiclehistory entity. @author MyEclipse Persistence Tools
 */

public class Vehiclehistory  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String description;
     private Vehiclehistorytype vehiclehistorytype;


    // Constructors

    /** default constructor */
    public Vehiclehistory() {
    }

    
    /** full constructor */
    public Vehiclehistory(String description, Vehiclehistorytype vehiclehistorytype) {
        this.description = description;
        this.vehiclehistorytype = vehiclehistorytype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public Vehiclehistorytype getVehiclehistorytype() {
        return this.vehiclehistorytype;
    }
    
    public void setVehiclehistorytype(Vehiclehistorytype vehiclehistorytype) {
        this.vehiclehistorytype = vehiclehistorytype;
    }
   








}