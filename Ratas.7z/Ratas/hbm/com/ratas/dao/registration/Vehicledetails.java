package com.ratas.dao.registration;

import java.util.Date;


/**
 * Vehicledetails entity. @author MyEclipse Persistence Tools
 */

public class Vehicledetails  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String manufacturer;
     private Date yearofmfg;
     private String noofcyl;
     private String chasisno;
     private String engno;
     private String hp;
     private String makeclass;
     private String seatingcap;
     private String unweight;
     private String color;
     private String fuelused;
     private String bodytype;
     private String insname;
     private String pucc;
     private String roadtax;


    // Constructors

    /** default constructor */
    public Vehicledetails() {
    }

    
    /** full constructor */
    public Vehicledetails(String manufacturer, Date yearofmfg, String noofcyl, String chasisno, String engno, String hp, String makeclass, String seatingcap, String unweight, String color, String fuelused, String bodytype, String insname, String pucc, String roadtax) {
        this.manufacturer = manufacturer;
        this.yearofmfg = yearofmfg;
        this.noofcyl = noofcyl;
        this.chasisno = chasisno;
        this.engno = engno;
        this.hp = hp;
        this.makeclass = makeclass;
        this.seatingcap = seatingcap;
        this.unweight = unweight;
        this.color = color;
        this.fuelused = fuelused;
        this.bodytype = bodytype;
        this.insname = insname;
        this.pucc = pucc;
        this.roadtax = roadtax;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getManufacturer() {
        return this.manufacturer;
    }
    
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Date getYearofmfg() {
        return this.yearofmfg;
    }
    
    public void setYearofmfg(Date yearofmfg) {
        this.yearofmfg = yearofmfg;
    }

    public String getNoofcyl() {
        return this.noofcyl;
    }
    
    public void setNoofcyl(String noofcyl) {
        this.noofcyl = noofcyl;
    }

    public String getChasisno() {
        return this.chasisno;
    }
    
    public void setChasisno(String chasisno) {
        this.chasisno = chasisno;
    }

    public String getEngno() {
        return this.engno;
    }
    
    public void setEngno(String engno) {
        this.engno = engno;
    }

    public String getHp() {
        return this.hp;
    }
    
    public void setHp(String hp) {
        this.hp = hp;
    }

    public String getMakeclass() {
        return this.makeclass;
    }
    
    public void setMakeclass(String makeclass) {
        this.makeclass = makeclass;
    }

    public String getSeatingcap() {
        return this.seatingcap;
    }
    
    public void setSeatingcap(String seatingcap) {
        this.seatingcap = seatingcap;
    }

    public String getUnweight() {
        return this.unweight;
    }
    
    public void setUnweight(String unweight) {
        this.unweight = unweight;
    }

    public String getColor() {
        return this.color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }

    public String getFuelused() {
        return this.fuelused;
    }
    
    public void setFuelused(String fuelused) {
        this.fuelused = fuelused;
    }

    public String getBodytype() {
        return this.bodytype;
    }
    
    public void setBodytype(String bodytype) {
        this.bodytype = bodytype;
    }

    public String getInsname() {
        return this.insname;
    }
    
    public void setInsname(String insname) {
        this.insname = insname;
    }

    public String getPucc() {
        return this.pucc;
    }
    
    public void setPucc(String pucc) {
        this.pucc = pucc;
    }

    public String getRoadtax() {
        return this.roadtax;
    }
    
    public void setRoadtax(String roadtax) {
        this.roadtax = roadtax;
    }
   








}