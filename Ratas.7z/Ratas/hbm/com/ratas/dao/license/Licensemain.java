package com.ratas.dao.license;

import com.ratas.dao.commons.Proofs;
import java.util.Date;


/**
 * Licensemain entity. @author MyEclipse Persistence Tools
 */

public class Licensemain  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String userid;
     private Date expirydate;
     private Licensetype licensetype;
     private Proofs proofid;


    // Constructors

    /** default constructor */
    public Licensemain() {
    }

    
    /** full constructor */
    public Licensemain(String userid, Date expirydate, Licensetype licensetype, Proofs proofid) {
        this.userid = userid;
        this.expirydate = expirydate;
        this.licensetype = licensetype;
        this.proofid = proofid;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getUserid() {
        return this.userid;
    }
    
    public void setUserid(String userid) {
        this.userid = userid;
    }

    public Date getExpirydate() {
        return this.expirydate;
    }
    
    public void setExpirydate(Date expirydate) {
        this.expirydate = expirydate;
    }

    public Licensetype getLicensetype() {
        return this.licensetype;
    }
    
    public void setLicensetype(Licensetype licensetype) {
        this.licensetype = licensetype;
    }

    public Proofs getProofid() {
        return this.proofid;
    }
    
    public void setProofid(Proofs proofid) {
        this.proofid = proofid;
    }
   








}