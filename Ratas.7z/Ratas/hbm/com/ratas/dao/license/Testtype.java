package com.ratas.dao.license;



/**
 * Testtype entity. @author MyEclipse Persistence Tools
 */

public class Testtype  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String testtype;


    // Constructors

    /** default constructor */
    public Testtype() {
    }

    
    /** full constructor */
    public Testtype(String testtype) {
        this.testtype = testtype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getTesttype() {
        return this.testtype;
    }
    
    public void setTesttype(String testtype) {
        this.testtype = testtype;
    }
   








}