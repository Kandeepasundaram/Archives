package com.ratas.dao.license;



/**
 * Licensehistorytype entity. @author MyEclipse Persistence Tools
 */

public class Licensehistorytype  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String historytype;


    // Constructors

    /** default constructor */
    public Licensehistorytype() {
    }

    
    /** full constructor */
    public Licensehistorytype(String historytype) {
        this.historytype = historytype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getHistorytype() {
        return this.historytype;
    }
    
    public void setHistorytype(String historytype) {
        this.historytype = historytype;
    }
   








}