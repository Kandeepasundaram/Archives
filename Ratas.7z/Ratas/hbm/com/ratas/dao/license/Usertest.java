package com.ratas.dao.license;

import java.util.Date;


/**
 * Usertest entity. @author MyEclipse Persistence Tools
 */

public class Usertest  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String userid;
     private Date date;
     private String result;
     private String testingauthority;
     private Testtype testtype;


    // Constructors

    /** default constructor */
    public Usertest() {
    }

    
    /** full constructor */
    public Usertest(String userid, Date date, String result, String testingauthority, Testtype testtype) {
        this.userid = userid;
        this.date = date;
        this.result = result;
        this.testingauthority = testingauthority;
        this.testtype = testtype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getUserid() {
        return this.userid;
    }
    
    public void setUserid(String userid) {
        this.userid = userid;
    }

    public Date getDate() {
        return this.date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }

    public String getResult() {
        return this.result;
    }
    
    public void setResult(String result) {
        this.result = result;
    }

    public String getTestingauthority() {
        return this.testingauthority;
    }
    
    public void setTestingauthority(String testingauthority) {
        this.testingauthority = testingauthority;
    }

    public Testtype getTesttype() {
        return this.testtype;
    }
    
    public void setTesttype(Testtype testtype) {
        this.testtype = testtype;
    }
   








}