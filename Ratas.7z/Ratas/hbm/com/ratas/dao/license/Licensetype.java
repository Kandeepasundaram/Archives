package com.ratas.dao.license;



/**
 * Licensetype entity. @author MyEclipse Persistence Tools
 */

public class Licensetype  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String licensetype;
     private String noofendorsements;


    // Constructors

    /** default constructor */
    public Licensetype() {
    }

    
    /** full constructor */
    public Licensetype(String licensetype, String noofendorsements) {
        this.licensetype = licensetype;
        this.noofendorsements = noofendorsements;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getLicensetype() {
        return this.licensetype;
    }
    
    public void setLicensetype(String licensetype) {
        this.licensetype = licensetype;
    }

    public String getNoofendorsements() {
        return this.noofendorsements;
    }
    
    public void setNoofendorsements(String noofendorsements) {
        this.noofendorsements = noofendorsements;
    }
   








}