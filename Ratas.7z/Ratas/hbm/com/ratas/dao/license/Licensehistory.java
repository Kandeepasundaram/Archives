package com.ratas.dao.license;



/**
 * Licensehistory entity. @author MyEclipse Persistence Tools
 */

public class Licensehistory  implements java.io.Serializable {


    // Fields    

     private long pkid;
     private String licenseid;
     private String description;
     private Licensehistorytype licensehistorytype;


    // Constructors

    /** default constructor */
    public Licensehistory() {
    }

    
    /** full constructor */
    public Licensehistory(String licenseid, String description, Licensehistorytype licensehistorytype) {
        this.licenseid = licenseid;
        this.description = description;
        this.licensehistorytype = licensehistorytype;
    }

   
    // Property accessors

    public long getPkid() {
        return this.pkid;
    }
    
    public void setPkid(long pkid) {
        this.pkid = pkid;
    }

    public String getLicenseid() {
        return this.licenseid;
    }
    
    public void setLicenseid(String licenseid) {
        this.licenseid = licenseid;
    }

    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public Licensehistorytype getLicensehistorytype() {
        return this.licensehistorytype;
    }
    
    public void setLicensehistorytype(Licensehistorytype licensehistorytype) {
        this.licensehistorytype = licensehistorytype;
    }
   








}