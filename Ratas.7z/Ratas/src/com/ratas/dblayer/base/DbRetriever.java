package com.ratas.dblayer.base;

import java.math.BigInteger;
import java.util.List;

import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;
import com.ratas.utils.CryptoLibrary;


public final class DbRetriever
{
	private static DbOperator dbOperator;


	private static class DbInnerClass
	{
		private static DbRetriever instance = new DbRetriever();
	}

	public synchronized static final DbRetriever getInstance()
	{
		dbOperator = DbOperator.getInstance();
		return DbInnerClass.instance;
	}	
	private DbRetriever()
	{

	}
	
	public boolean merge(Object object)
	{

		return dbOperator.merge(object);
	}

	public boolean saveOrUpdate(Object object)
	{
		return dbOperator.saveOrUpdate(object);
	}
	
	public Object getObject(String sqlString)
	{
		return dbOperator.getObject(sqlString);
	}
	
	public int getCount(String query)
	{
		int count = 0;
		BigInteger b = (BigInteger) fireSqlForAnObject(query);
		System.out.println(b);
		if(b != null)
			count = b.intValue();
		return count;
	}

	public List<?> getObjects(String sqlString)
	{
		return dbOperator.getObjects(sqlString);
	}

	public Object getObjectsById(Class<?> className, String pkid)
	{
		//return dbInteractor.getAllObjects(className);
		return dbOperator.getObject("from " + className.getCanonicalName() + " where pkid=" + pkid);
	}

	public Object fireSqlForAnObject(String sqlString)
	{
		return dbOperator.fireSqlForAnObject(sqlString);
	}
	
	public List<?> fireSqlForObjects(String sqlString)
	{
		return dbOperator.fireSqlForObjects(sqlString);
	}
	
	public Users getUser(String userName , String passWord)
	{
		Users user = null;//(Users) dbOperator.fireSqlForAnObject(" from " + Users.class.getCanonicalName() + " where username = 'Guest' and password = 'Guest'");
		System.out.println(userName + ":" + passWord);
		CryptoLibrary crypto = new CryptoLibrary();
		if (userName != null && passWord != null) {
			user = (Users) dbOperator.getObject(" from " + Users.class.getCanonicalName() +" where username = '" + userName + "' and password = '" + crypto.encrypt(passWord)
					+ "'");
			System.out.println("In Retriever");
		}
		return user;
	}
	
	public List<Zones> getZonesList() {
		List<Zones> listOfZones = (List<Zones>) DbRetriever.getInstance().getObjects(" from " + Zones.class.getCanonicalName() + " order by district");
		return listOfZones;
	}
	
	public Zones getZone(String pkid)
	{
		Zones zone = (Zones) DbRetriever.getInstance().getObjectsById(Zones.class, pkid);
		return zone;
	}
	
	public int getNoOfUsersToAuthorize(long pkid)
	{
		String QUERY = "select count(*) from Users where zone = " + pkid;
		int noOfUsersToAuthorize = DbRetriever.getInstance().getCount(QUERY);
		return noOfUsersToAuthorize;
	}
}
