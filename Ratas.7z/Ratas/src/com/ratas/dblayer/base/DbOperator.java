/**
 * 
 */
package com.ratas.dblayer.base;

import java.util.List;

/**
 * @author KS
 *
 */
public class DbOperator 
{

	private DbInteractor dbInteractor;
	
	
	private static class DbInnerClass
	{
		private static DbOperator instance = new DbOperator();
	}

	public synchronized static final DbOperator getInstance()
	{
		return DbInnerClass.instance;
	}

	private DbOperator()
	{
		dbInteractor = new DbInteractor();
	}
	
	public boolean merge(Object object)
	{

		return dbInteractor.merge(object);
	}

	public boolean saveOrUpdate(Object object)
	{
		return dbInteractor.saveOrUpdate(object);
	}

	public Object getObject(String sqlString)
	{
		return dbInteractor.getObject(sqlString);
	}

	public List<?> getObjects(String sqlString)
	{
		return dbInteractor.getObjects(sqlString);
	}

	public Object getObjectsById(Class<?> className, String pkid)
	{
		//return dbInteractor.getAllObjects(className);
		return dbInteractor.getObject("from " + className.getCanonicalName() + " where pkid=" + pkid);
	}

	public List<Object> getAllObjects(Class<?> className)
	{
		//return dbInteractor.getAllObjects(className);
		return dbInteractor.getObjects("from " + className.getCanonicalName());
	}

	public Object fireSqlForAnObject(String sqlString)
	{
		System.out.println("In Operator");
		return dbInteractor.fireSqlForAnObject(sqlString);
	}
	
	public List<?> fireSqlForObjects(String sqlString)
	{
		return dbInteractor.fireSqlForObjects(sqlString);
	}
}
