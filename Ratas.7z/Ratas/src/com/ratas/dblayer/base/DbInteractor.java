package com.ratas.dblayer.base;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DbInteractor 
{
	private SessionFactory sessionFactory;
	
	protected DbInteractor() 
	{
		try 
		{
			buildSessionFactory();
		}
		catch (Exception e) {
			System.out.println("ERROR IN BUILDING SESSION FACTORY : " + e);
		}
	}
	
	private void buildSessionFactory()
	{
		Configuration configuration = new Configuration().configure(new File("D:\\Ratas\\config\\hibernate.cfg.xml"));
		sessionFactory = configuration.buildSessionFactory();
	}
	
	
	/**
	 * Save or Update any object to DB
	 * 
	 * @param object
	 */
	protected boolean saveOrUpdate(Object object)
	{
		Session session = null;
		Transaction transaction = null;
		try
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			try{
				session.saveOrUpdate(object);
			}
			catch (NonUniqueObjectException e) {
			}
			session.flush();
			transaction.commit();
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (session.isOpen())
			{
				session.close();
			}
			session = null;
			transaction = null;
		}
		return true;
	}
	
	
	/**
	 * Merges the session object to DB
	 * @param object
	 */
	protected boolean merge(Object object)
	{
		Session session = null;
		Transaction transaction = null;
		try
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.merge(object);
			session.flush();
			session.evict(object);
			transaction.commit();
		} 
		catch (Exception e)
		{
			transaction.rollback();
			e.printStackTrace();
		} 
		finally
		{

			if (session.isOpen())
			{
				session.close();
			}
			session = null;
			transaction = null;
		}
		return true;
	}
	
	/**
	 * retrieve first object from result set of HQL
	 * @param hqlString
	 * @return
	 */
	protected Object getObject(String hqlString)
	{
		Session session = null;

		try
		{

			session = sessionFactory.openSession();
			List<Object> objects = null;
			objects = session.createQuery(hqlString).list();
			Object object = null;
			if(objects.size()>0)
			{
				object = objects.get(0);
			}
			session.evict(object);
			return object;
		} finally
		{
			if (session != null)
			{
				session.close();
			}
		}

	}

	/**
	 * retrieves result sets of HQL
	 * @param hqlString
	 * @return
	 */
	protected List getObjects(String hqlString)
	{
		Session session = null;

		try
		{

			session = sessionFactory.openSession();
			List<Object> objects = session.createQuery(hqlString).list();
			session.evict(objects);
			return objects;
		} finally
		{
			if (session != null)
			{
				session.close();
			}
		}
	}
	
	
	/**
     * Fire a SQL command
     * @param sqlString
     * @return
     */
    public Object fireSqlForAnObject(String sqlString)
    {
        List<?> list = null;
        Transaction tx = null;
        Session session = null;
        try
        {
            session = sessionFactory.openSession();
            tx = session.beginTransaction();
            list = session.createSQLQuery(sqlString).list();
            System.out.println(list.size());
        }
        catch (Throwable thx)
        {
        	thx.printStackTrace();        	
        }
        finally
        {
            if(tx != null)
            {
                tx.commit();
                tx = null;
            }
            if (session != null && session.isOpen())
            {
                session.close();
                session = null;
            }
        }
        if(list != null)
        {
        	System.out.println("LIST NOT ");
        	if(list.size() > 0)
        	{
        		System.out.println("NOT NULL");
        		return list.get(0);
        	}
        	else
        		return null;
        }
        else
        {
        	System.out.println("DBInteractor : List is null");
        	return null;
        }
    }
    
    /**
     * Fire a SQL command
     * @param sqlString
     * @return
     */
    public List<?> fireSqlForObjects(String sqlString)
    {
        List<?> list = null;
        Transaction tx = null;
        Session session = null;
        try
        {
            session = sessionFactory.openSession();
            tx = session.beginTransaction();
            list = session.createSQLQuery(sqlString).list();
        }
        catch (Throwable thx)
        {
        	
        }
        finally
        {
            if(tx != null)
            {
                tx.commit();
                tx = null;
            }
            if (session != null && session.isOpen())
            {
                session.close();
                session = null;
            }
        }
        if(list.size() > 0)
        	return list;
        else
        	return null;
    }
}
