package com.ratas.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Calendar
{
   
    private HashMap<Integer, Boolean> isWeekend;
    private HashMap<Date, Boolean> isNationalHoliday;
    private static Calendar instance;
   
    public static synchronized Calendar getInstance()
    {
        if(instance == null)
            instance = new Calendar();
        return instance;
    }
   
    /**
     * Format DAY/MONTH/YEAR example 01/05/2009
     * @param dateInString
     * @return
     */
    private Date getDate(int date, int month, int year)
    {
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        calendar.set(java.util.Calendar.DATE, date);
        calendar.set(java.util.Calendar.MONTH, (month-1));
        calendar.set(java.util.Calendar.YEAR, year);
        return calendar.getTime();
    }
   
    @SuppressWarnings("deprecation")
    private Calendar()
    {
        isWeekend = new HashMap<Integer, Boolean>();
        isWeekend.put(java.util.Calendar.SATURDAY, true);
        isWeekend.put(java.util.Calendar.SUNDAY, true);
        isNationalHoliday = new HashMap<Date, Boolean>();
        isNationalHoliday.put(getDate(1,5,2009), true);
    }
   
    public static void main(String[] args)
    {
        Calendar calendar = Calendar.getInstance();
        List<Date> dates = calendar.getWorkingDates(new Date(), 30);
        int i = 1;
        for(Date date : dates)
        {
            System.out.println("No : " + i + " : " + date);
            i++;
        }
    }
   
    public List<Date> getWorkingDates(Date startingDate, int noOfWorkingDays)
    {
        List<Date> listOfWorkingDates = new LinkedList<Date>();
        java.util.Calendar fromDate = java.util.Calendar.getInstance();
        java.util.Calendar toDate = java.util.Calendar.getInstance();
        java.util.Calendar date = java.util.Calendar.getInstance();
        fromDate.setTime(startingDate);
        toDate.setTime(startingDate);
        date.setTime(startingDate);
        toDate.add(java.util.Calendar.DATE, noOfWorkingDays);
        for(int i = 0 ; i < noOfWorkingDays && toDate.after(fromDate);)
        {
            date.add(java.util.Calendar.DATE, 1);
            if(isWeekend.get(date.get(java.util.Calendar.DAY_OF_WEEK)) == null)
            {
                listOfWorkingDates.add(date.getTime());
                i++;
            }
        }
        return listOfWorkingDates;
    }

}

