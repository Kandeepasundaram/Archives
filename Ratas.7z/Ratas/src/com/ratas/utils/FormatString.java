package com.ratas.utils;

import java.util.regex.Pattern;

/**
 * 
 * @author Kandeepan
 * @author KS
 *
 */
public final class FormatString 
{
	final Pattern PATTERN = Pattern.compile("([^a-zA-z0-9.@/, -])");
	/**
	 * All Strings passed in will be trimmed to left and right
	 * @param context
	 * @return context
	 */
	public String trimString(String context)
	{
		context = context.trim();
		return context;
	}

	/**
	 * The method is used to format a sentence such that all words after a ',' will start with Uppercase 
	 * @param context
	 * @return context
	 */
	public String formatSentence(String context)
	{
		String words[] = context.split(",");
		String tempContext = "";
		for (String word : words) 
		{
			word = trimString(word);

			word = word.substring(0,1).toUpperCase() + word.substring(1).toLowerCase();
			tempContext = tempContext + word + ", ";			
			System.out.println(tempContext);
			
		}
		context = tempContext.substring(0, tempContext.length()-2);

		System.out.println("formatSentence " + context);
		
		
		return context;
	}

	/**
	 * Returns the String after removing all characters that are not specified in the Pattern pattern
	 */
	public String escapeRE(String str) {
		return PATTERN.matcher(str).replaceAll("");
	}


	public static void main(String[] args)
	{
		FormatString formatString = new FormatString();
		String context = " 21/b , SFAdfd -. @##asudh ";
		System.out.println("Original String : " + context);
		context = formatString.trimString(context);
		System.out.println("Trimmed String (" + context + ")");
		context = formatString.formatSentence(context);
		System.out.println("Formatted String (" + context + ")");
		context = formatString.escapeRE(context);
		System.out.println("Final :" + context);
	}
}



