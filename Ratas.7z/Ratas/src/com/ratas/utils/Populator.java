package com.ratas.utils;

import java.util.Date;

import com.ratas.config.constants.RatasConstants;
import com.ratas.config.constants.UserTypeEnum;
import com.ratas.dao.commons.UserType;
import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;
import com.ratas.dblayer.base.DbRetriever;

public class Populator 
{
	public static void main(String[] args) 
	{
		Populator populator = new Populator();
		populator.addUserTypes();
		populator.addZones();
		populator.addSuperUser();
	}
	
	//Add UserTypes
	public void addUserTypes()
	{
		for (UserTypeEnum userType : UserTypeEnum.values()) 
		{
			UserType type = new UserType(userType.getUserType());
			DbRetriever.getInstance().saveOrUpdate(type);
		}
	}
	
	//Add Zones
	public void addZones()
	{
		Zones zones = new Zones("CBE North" , "Coimbatore" , "Tamilnadu" ,"TN 37" , "30");
		Zones zones2 = new Zones("CBE South" , "Coimbatore" , "Tamilnadu" ,"TN 38" , "30");
		
		DbRetriever.getInstance().saveOrUpdate(zones);
		DbRetriever.getInstance().saveOrUpdate(zones2);
	}
	
	//Add Users
	public void addSuperUser()
	{
		String superuser = "super";
		Users users = new Users();
		
		CryptoLibrary crypto = new CryptoLibrary();
		
		
		users.setUsername(superuser);
		users.setPassword(crypto.encrypt(superuser));
		users.setAuthorized(RatasConstants.YES);
		users.setDoa(new Date());
		
		UserType userType = (UserType) DbRetriever.getInstance().getObjectsById(UserType.class, UserTypeEnum.SUPERUSER.getPkid()+"");
		users.setUsertype(userType);
		
		DbRetriever.getInstance().saveOrUpdate(users);
	}
}
