package com.ratas.config.constants;

import com.ratas.dblayer.base.DbRetriever;


public class Dummy {
	public static void main(String[] args) 
	{
	DbRetriever.getInstance();
		System.out.println(UserTypeEnum.OPERATOR);
		System.out.println(UserTypeEnum.OPERATOR.getPkid());
		System.out.println(UserTypeEnum.OPERATOR.getUserType());
		System.out.println(UserTypeEnum.getId(1L));
		System.out.println(UserTypeEnum.getName("Operator"));
		
		UserTypeEnum key = UserTypeEnum.getName(UserTypeEnum.OPERATOR.userType); 
		
		switch (key) {
		case SUPERUSER:
			System.out.println("super");
			break;
		case OPERATOR:
			System.out.println(key.userType);
			System.out.println(key.pkid);
			System.out.println(key);
			break;
		default:
			break;
		}
	}
}
