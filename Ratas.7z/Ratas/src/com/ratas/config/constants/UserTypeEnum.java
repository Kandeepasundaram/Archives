/**
 * 
 */
package com.ratas.config.constants;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author KS
 *
 */
public enum UserTypeEnum {
	
	SUPERUSER("Super User" , 1L),
	ADMINISTRATOR("Administrator" , 2L),
	OPERATOR("Operator" , 3L),
	CITIZEN("Citizen" , 4L);
	
	private static final Map<String , UserTypeEnum> nameIt = new HashMap<String, UserTypeEnum>();
	private static final Map<Long , UserTypeEnum> idIt = new HashMap<Long , UserTypeEnum>();
	
	static 
	{
		for (UserTypeEnum uType : EnumSet.allOf(UserTypeEnum.class)) {
			nameIt.put(uType.getUserType(), uType);
			idIt.put(uType.getPkid() , uType);
		}
	}

	public String userType;
	public long pkid;
	
	private UserTypeEnum(String userType , long pkid)
	{
		this.userType = userType;
		this.pkid = pkid;
	}

	public String getUserType() {
		return userType;
	}
	
	public long getPkid() {
		return pkid;
	}

	public static UserTypeEnum getName(String userType)
	{
		return nameIt.get(userType);
	}
	
	public static UserTypeEnum getId(long pkid)
	{
		return idIt.get(pkid);
	}
	

}
