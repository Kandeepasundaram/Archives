/**
 * 
 */
package com.ratas.config.constants;

import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;

/**
 * @author KS
 *
 */
public final class RatasConstants {
	
	/**
	 * General Values
	 */
	public static final String YES = "Yes";
	public static final String NO = "No";
	
	/**
	 * Session Constants
	 */
	public static final String USER_LOGINED = "logined";
	
	
	/**
	 * Query Strings
	 */
	//get list of zones order by district names
	public static final String ZONESLISTQUERY = " from " + Zones.class.getCanonicalName() + " order by district";
	//get list of administrator users of a particular zone (based on zone pkid)
	public static final String ADMINLISTQUERY = " from " + Users.class.getCanonicalName() + " where usertype = " + UserTypeEnum.ADMINISTRATOR.getPkid() + " and zone = ";
	//get list of operator users belonging to the appropriate administrator's zone (based on zone pkid)
	public static final String OPERATORLISTQUERY = " from " + Users.class.getCanonicalName() + " where usertype = " + UserTypeEnum.OPERATOR.getPkid() + " and zone = ";
	
	
}
