package com.ratas.action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ratas.action.login.UserSession;
import com.ratas.config.constants.RatasConstants;

public class RatasSupport extends ActionSupport 
{
	
	private UserSession userInfo;
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return super.execute();
	}

	@Override
	public String input() throws Exception {
		// TODO Auto-generated method stub
		return super.input();
	}

	public UserSession getUserInfo() {
		Map session = ActionContext.getContext().getSession();
		userInfo = (UserSession) session.get(RatasConstants.USER_LOGINED);
		return userInfo;
	}

	public void setUserInfo(UserSession userInfo) {
		this.userInfo = userInfo;
	}

}
