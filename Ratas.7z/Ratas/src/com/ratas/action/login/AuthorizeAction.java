package com.ratas.action.login;

import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ratas.config.constants.RatasConstants;
import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;
import com.ratas.dblayer.base.DbRetriever;

public class AuthorizeAction extends ActionSupport 
{
	private String userName;
	private String passWord;

	@Override
	public String execute() throws Exception {
		if ((getUserName() != null) && (getPassWord() != null))
		{
			Users user = DbRetriever.getInstance().getUser(getUserName(), getPassWord());
			if (user != null) 
			{
				UserSession ratasUser = new UserSession();
				ratasUser = addAppSubOrdinates(ratasUser);
				ratasUser.setUser(user);
				
				Map session = ActionContext.getContext().getSession();
				session.put(RatasConstants.USER_LOGINED, ratasUser);
			}
		}
		return super.execute();
	}
	
	private UserSession addAppSubOrdinates(UserSession userSession)
	{
		List<Zones> listOfZones = new Vector<Zones>();
		listOfZones = DbRetriever.getInstance().getZonesList();
		userSession.setListOfZones(listOfZones);
		return userSession;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

}
