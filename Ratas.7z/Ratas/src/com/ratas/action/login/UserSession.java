package com.ratas.action.login;

import java.util.List;

import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;

public class UserSession {
	/**
	 * 
	 */
	private Users user;
	private List<Zones> listOfZones;

	public List<Zones> getListOfZones() {
		return listOfZones;
	}

	public void setListOfZones(List<Zones> listOfZones) {
		this.listOfZones = listOfZones;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

}
