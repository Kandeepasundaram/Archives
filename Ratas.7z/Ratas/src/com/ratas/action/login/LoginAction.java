package com.ratas.action.login;

import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.jgroups.demos.wb.UserInfoDialog;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ratas.action.RatasSupport;
import com.ratas.config.constants.RatasConstants;
import com.ratas.config.constants.RatasQueryConstants;
import com.ratas.config.constants.UserTypeEnum;
import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;
import com.ratas.dblayer.base.DbRetriever;
import com.ratas.pojo.ZoneUsersPojo;

public class LoginAction extends RatasSupport {

	private String userName;
	private String passWord;
	
	private int noOfUsersToBeAuthorized;

	private List<Zones> listOfZones;

	private List<ZoneUsersPojo> listOfAdmins;
	private List<ZoneUsersPojo> listOfOperators;
	

	@Override
	public String input() throws Exception {
		// TODO Auto-generated method stub
		return INPUT;
	}

	/* (non-Javadoc)
	 * @see com.opensymphony.xwork2.ActionSupport#execute()
	 */
	@Override
	public String execute() throws Exception {
		listOfZones = new Vector<Zones>();
		List<Users> listOfMembers = new Vector<Users>();
		listOfAdmins = new Vector<ZoneUsersPojo>();
		listOfOperators = new Vector<ZoneUsersPojo>();
		UserTypeEnum key = UserTypeEnum.getName(getUserInfo().getUser().getUsertype().getUsertype()); 
		if (key != null) 
		{
			switch (key) 
			{
			case SUPERUSER:
				listOfZones = DbRetriever.getInstance().getZonesList();
				for (Zones zone : listOfZones) 
				{
					ZoneUsersPojo pojo = new ZoneUsersPojo();
					listOfMembers = (List<Users>) DbRetriever.getInstance().getObjects(RatasConstants.ADMINLISTQUERY + zone.getPkid());
					if (listOfMembers.size() > 0) 
					{
						pojo.setZoneName(zone.getZone());
						pojo.setListOfUsers(listOfMembers);
						listOfAdmins.add(pojo);
					}
				}
				setListOfAdmins(listOfAdmins);
				return "sudo";
			case ADMINISTRATOR:
				listOfMembers = (List<Users>) DbRetriever.getInstance().getObjects(RatasConstants.OPERATORLISTQUERY + getUserInfo().getUser().getZone().getPkid());
				ZoneUsersPojo pojo = new ZoneUsersPojo();
				if (listOfMembers.size() > 0) 
				{
					pojo.setZoneName(getUserInfo().getUser().getZone().getZone());
					pojo.setListOfUsers(listOfMembers);
					listOfOperators.add(pojo);
				}
				return "admin";
			case OPERATOR:
				noOfUsersToBeAuthorized = DbRetriever.getInstance().getNoOfUsersToAuthorize(getUserInfo().getUser().getZone().getPkid());
				
				return "operator";
			case CITIZEN:
				return "citizen";
			default:
				return ERROR;
			}
		}
		return ERROR;
	}
	
	public String logout() {
		Map session = ActionContext.getContext().getSession();
		session.remove(RatasConstants.USER_LOGINED);
		return "logout";
	}

	public List<ZoneUsersPojo> getListOfOperators() {
		return listOfOperators;
	}

	public void setListOfOperators(List<ZoneUsersPojo> listOfOperators) {
		this.listOfOperators = listOfOperators;
	}

	public List<ZoneUsersPojo> getListOfAdmins() {
		return listOfAdmins;
	}

	public void setListOfAdmins(List<ZoneUsersPojo> listOfAdmins) {
		this.listOfAdmins = listOfAdmins;
	}

	public List<Zones> getListOfZones() {
		return listOfZones;
	}

	public void setListOfZones(List<Zones> listOfZones) {
		this.listOfZones = listOfZones;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public int getNoOfUsersToBeAuthorized() {
		return noOfUsersToBeAuthorized;
	}

	public void setNoOfUsersToBeAuthorized(int noOfUsersToBeAuthorized) {
		this.noOfUsersToBeAuthorized = noOfUsersToBeAuthorized;
	}
}
