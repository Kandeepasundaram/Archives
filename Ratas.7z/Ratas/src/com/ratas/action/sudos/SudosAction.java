package com.ratas.action.sudos;

import java.util.Date;
import java.util.List;
import java.util.Vector;

import com.opensymphony.xwork2.ActionSupport;
import com.ratas.action.RatasSupport;
import com.ratas.config.constants.RatasConstants;
import com.ratas.config.constants.UserTypeEnum;
import com.ratas.dao.commons.Personal;
import com.ratas.dao.commons.UserType;
import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;
import com.ratas.dblayer.base.DbRetriever;
import com.ratas.utils.CryptoLibrary;

public class SudosAction extends RatasSupport 
{
	private String view;

	//Variables Required for Zone Creation & Editing
	private String zonepkid;

	private String zone;
	private String district;
	private String state;
	private String rtocode;
	private String noofappointments;

	//Variables Requires for Administrator Creation & Editing
	private String adminName;
	private String passWord;
	private String authorized;
	private Date dateRegistered;
	private String zoneId;
	
	private String adminPkid;

	//Variable Required for Input Forms
	private List<Zones> listOfZones;

	@Override
	public String input() throws Exception {
		System.out.println("Inside Sudos Action Class : " + getUserInfo().getUser().getUsername());
		setView(getView());
		if (getZonepkid() != null) 
		{
			Zones zones = (Zones) DbRetriever.getInstance().getObject(" from " + Zones.class.getCanonicalName() + " where pkid = " + getZonepkid());
			setZone(zones.getZone());
			setDistrict(zones.getDistrict());
			setState(zones.getState());
			setRtocode(zones.getRtocode());
			setNoofappointments(zones.getNoofappointments());
		}
		else if (getAdminPkid() != null)
		{
			Users users = (Users) DbRetriever.getInstance().getObject(" from " + Users.class.getCanonicalName() + " where pkid = " + getAdminPkid());
			setAdminName(users.getUsername());
			setZoneId(users.getZone().getZone());
		}
		listOfZones = new Vector<Zones>();
		listOfZones = DbRetriever.getInstance().getZonesList();

		return INPUT;
	}

	/**
	 * 
	 * @return
	 */
	public String addZone() 
	{
		Zones zones;
		if (getZonepkid() != null && getZonepkid().length() > 0) {
			zones = (Zones) DbRetriever.getInstance().getObjectsById(Zones.class, getZonepkid());
		}
		else
		{
			zones = new Zones();
		}
		zones.setZone(getZone());
		zones.setDistrict(getDistrict());
		zones.setState(getState());
		zones.setRtocode(getRtocode());
		zones.setNoofappointments(getNoofappointments());

		DbRetriever.getInstance().saveOrUpdate(zones);

		System.out.println("Zones Added Successfully");

		setView("view");
		return SUCCESS;
	}

	public String addAdmin() 
	{
		CryptoLibrary crypto = new CryptoLibrary();

		Users users;
		
		if (getAdminPkid() != null && getAdminPkid().length() > 0) 
		{
			System.out.println("Not null");
			users = (Users) DbRetriever.getInstance().getObjectsById(Users.class, getAdminPkid());
		} 
		else
		{
			System.out.println("Null");
			users = new Users();
		}
		users.setUsername(getAdminName());
		users.setPassword(crypto.encrypt(getPassWord()));
		users.setAuthorized(RatasConstants.YES);
		users.setDoa(new Date());

		System.out.println("Zone Id : " + getZoneId());

		Zones zone = (Zones) DbRetriever.getInstance().getObjectsById(Zones.class, getZoneId());

		users.setZone(zone);

		UserType userType = (UserType) DbRetriever.getInstance().getObjectsById(UserType.class, UserTypeEnum.ADMINISTRATOR.getPkid() + "");

		System.out.println(userType.getPkid() + " : " + userType.getUsertype());

		Personal personal = new Personal();

		users.setUsertype(userType);
		users.setPersonal(personal);

		DbRetriever.getInstance().saveOrUpdate(users);

		System.out.println("Administrator : " + getAdminName() + " added as " + UserTypeEnum.ADMINISTRATOR);

		return SUCCESS;
	}

	@Override
	public String execute() throws Exception 
	{
		setListOfZones(DbRetriever.getInstance().getZonesList());
		return SUCCESS;
	}

	

	public String getAdminPkid() {
		return adminPkid;
	}

	public void setAdminPkid(String adminPkid) {
		this.adminPkid = adminPkid;
	}
	
	public String getZonepkid() {
		return zonepkid;
	}

	public void setZonepkid(String zonepkid) {
		this.zonepkid = zonepkid;
	}

	public List<Zones> getListOfZones() {
		return listOfZones;
	}


	public void setListOfZones(List<Zones> listOfZones) {
		this.listOfZones = listOfZones;
	}


	public String getAdminName() {
		return adminName;
	}


	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}


	public String getPassWord() {
		return passWord;
	}


	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}


	public String getAuthorized() {
		return authorized;
	}


	public void setAuthorized(String authorized) {
		this.authorized = authorized;
	}


	public Date getDateRegistered() {
		return dateRegistered;
	}


	public void setDateRegistered(Date dateRegistered) {
		this.dateRegistered = dateRegistered;
	}


	public String getZoneId() {
		return zoneId;
	}


	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}	


	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getRtocode() {
		return rtocode;
	}

	public void setRtocode(String rtocode) {
		this.rtocode = rtocode;
	}

	public String getNoofappointments() {
		return noofappointments;
	}

	public void setNoofappointments(String noofappointments) {
		this.noofappointments = noofappointments;
	}
}
