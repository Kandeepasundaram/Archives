package com.ratas.action.register;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import com.ratas.action.RatasSupport;
import com.ratas.config.constants.RatasConstants;
import com.ratas.config.constants.UserTypeEnum;
import com.ratas.dao.commons.Personal;
import com.ratas.dao.commons.UserType;
import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;
import com.ratas.dblayer.base.DbRetriever;
import com.ratas.utils.CryptoLibrary;

/**
 * <blockquote> Registration of Citizens are performed using this Class </blockquote>
 * @author Kandeepan
 * @author KS
 *
 */
public class RegisterAction extends RatasSupport
{
	private String view;
	
	
	private String newUserName;
	private String newPassWord;
	private String name;
	private String question;
	private String answer;
	private String authorized;
	private Date doa;
	private String firstName;
	private String secondName;	
	private Date dateofBirth;
	private String permanentAddress1;	
	private String permanentAddress2;
	private String contactAddress1;
	private String contactAddress2;	
	private String phone;
	private String mobile;	
	private String email;
	private String zoneName;
	
	//Variables Needed for FORM Init
	private List<Zones> listOfZones;
	
	
	public String input() throws Exception 
	{
		listOfZones = new Vector<Zones>();
		listOfZones = DbRetriever.getInstance().getZonesList();
		return INPUT;
	}

	public String register()
	{
		CryptoLibrary crypto = new CryptoLibrary();

		//Users users = (Users) DbRetriever.getInstance().getObject(" from " + Users.class.getCanonicalName());
		//Personal personal = (Personal)DbRetriever.getInstance().getObject(" from " + Users.class.getCanonicalName());

		Users users = new Users();
		Personal personal = new Personal();
		
		users.setUsername(getNewUserName());
		users.setPassword(crypto.encrypt(getNewPassWord()));
		users.setAuthorized(RatasConstants.NO);
		users.setDoa(new Date());
		users.setQuestion(getQuestion());
		users.setAnswer(getAnswer());
		Zones userZone = DbRetriever.getInstance().getZone(getZoneName());
		users.setZone(userZone);
		
		UserType userType = (UserType) DbRetriever.getInstance().getObjectsById(UserType.class, UserTypeEnum.CITIZEN.getPkid() + "");
		users.setUsertype(userType);
		
		personal.setFirstname(getFirstName());
		personal.setSecondname(getSecondName());
		personal.setDateofbirth(getDateofBirth());
		personal.setPermanentaddress1(getPermanentAddress1());
		personal.setPermanentaddress2(getPermanentAddress2());
		personal.setContactaddress1(getContactAddress1());
		personal.setContactaddress2(getContactAddress2());
		personal.setPhone(getPhone());
		personal.setMobile(getMobile());
		personal.setEmail(getEmail());
		personal.setUserid(users);
		DbRetriever.getInstance().saveOrUpdate(users);		
		DbRetriever.getInstance().saveOrUpdate(personal);
		System.out.println("USER REGISTRATION SUCCESSFUL");
		return SUCCESS;

	}

	public String execute() throws Exception 
	{
		addActionMessage("Registration Successful");
		return SUCCESS;
	}	

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getAuthorized() {
		return authorized;
	}

	public void setAuthorized(String authorized) {
		this.authorized = authorized;
	}

	public Date getDoa() {
		return doa;
	}

	public void setDoa(Date doa) {
		this.doa = doa;
	}	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSecondName() {
		return secondName;
	}

	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}

	public Date getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(Date dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public String getPermanentAddress1() {
		return permanentAddress1;
	}

	public void setPermanentAddress1(String permanentAddress1) {
		this.permanentAddress1 = permanentAddress1;
	}

	public String getPermanentAddress2() {
		return permanentAddress2;
	}

	public void setPermanentAddress2(String permanentAddress2) {
		this.permanentAddress2 = permanentAddress2;
	}

	public String getContactAddress1() {
		return contactAddress1;
	}

	public void setContactAddress1(String contactAddress1) {
		this.contactAddress1 = contactAddress1;
	}

	public String getContactAddress2() {
		return contactAddress2;
	}

	public void setContactAddress2(String contactAddress2) {
		this.contactAddress2 = contactAddress2;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}
	
	public String getNewUserName() {
		return newUserName;
	}

	public void setNewUserName(String newUserName) {
		this.newUserName = newUserName;
	}

	public String getNewPassWord() {
		return newPassWord;
	}

	public void setNewPassWord(String newPassWord) {
		this.newPassWord = newPassWord;
	}
	

	public List<Zones> getListOfZones() {
		return listOfZones;
	}

	public void setListOfZones(List<Zones> listOfZones) {
		this.listOfZones = listOfZones;
	}
	
	
	public String getZoneName() {
		return zoneName;
	}

	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}


}
