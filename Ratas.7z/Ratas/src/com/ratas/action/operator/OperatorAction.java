package com.ratas.action.operator;

import com.ratas.action.RatasSupport;

public class OperatorAction extends RatasSupport 
{
	@Override
	public String input() throws Exception {
		// TODO Auto-generated method stub
		return super.input();
	}
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return super.execute();
	}
}
