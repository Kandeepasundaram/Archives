package com.ratas.action.admin;

import java.util.Date;
import java.util.List;

import com.ratas.action.RatasSupport;
import com.ratas.config.constants.RatasConstants;
import com.ratas.config.constants.UserTypeEnum;
import com.ratas.dao.commons.Personal;
import com.ratas.dao.commons.UserType;
import com.ratas.dao.commons.Users;
import com.ratas.dao.commons.Zones;
import com.ratas.dblayer.base.DbRetriever;
import com.ratas.utils.CryptoLibrary;
/**
 * Action Class for performing Administrator Operations
 * @author KS
 *
 *
 *List Of Operations 
 *-------------------
 *Add Operator
 *
 */
public class AdminAction extends RatasSupport{
	private String view;

	private String zonepkid;

	//Variables Requires for Administrator Creation & Editing
	private String operatorName;
	private String passWord;
	private String authorized;
	private Date dateRegistered;
	private String zoneId;

	private String operatorPkid;
	
	//Variable Required for Input Forms
	private List<Zones> listOfZones;

	@Override
	public String input() throws Exception {
		System.out.println("Inside Admin Action Class : " + getUserInfo().getUser().getUsername());
		setView(getView());
		
		if (getOperatorPkid() != null)
		{
			System.out.println("syso :" + getOperatorPkid());
			Users users = (Users) DbRetriever.getInstance().getObject(" from " + Users.class.getCanonicalName() + " where pkid = " + getOperatorPkid());
			setOperatorName(users.getUsername());
			setZoneId(users.getZone().getZone());
		}
		return INPUT;
	}

	public String addOperator() 
	{
		CryptoLibrary crypto = new CryptoLibrary();

		Users users;

		if (getOperatorPkid() != null && getOperatorPkid().length() > 0) 
		{
			System.out.println("Not null");
			users = (Users) DbRetriever.getInstance().getObjectsById(Users.class, getOperatorPkid());
		} 
		else
		{
			System.out.println("Null");
			users = new Users();
		}
		users.setUsername(getOperatorName());
		users.setPassword(crypto.encrypt(getPassWord()));
		users.setAuthorized(RatasConstants.YES);
		users.setDoa(new Date());

		System.out.println("Zone Id : " + getZoneId());

		Zones zone = (Zones) DbRetriever.getInstance().getObjectsById(Zones.class, getZoneId());

		users.setZone(zone);

		UserType userType = (UserType) DbRetriever.getInstance().getObjectsById(UserType.class, UserTypeEnum.OPERATOR.getPkid() + "");

		System.out.println(userType.getPkid() + " : " + userType.getUsertype());

		Personal personal = new Personal();

		users.setUsertype(userType);
		users.setPersonal(personal);

		DbRetriever.getInstance().saveOrUpdate(users);

		System.out.println("Operator : " + getOperatorName() + " added as " + UserTypeEnum.OPERATOR);

		return SUCCESS;
	}

	@Override
	public String execute() throws Exception 
	{
		setListOfZones(DbRetriever.getInstance().getZonesList());
		return SUCCESS;
	}



	public String getOperatorPkid() {
		return operatorPkid;
	}

	public void setOperatorPkid(String operatorPkid) {
		this.operatorPkid = operatorPkid;
	}

	public String getZonepkid() {
		return zonepkid;
	}

	public void setZonepkid(String zonepkid) {
		this.zonepkid = zonepkid;
	}

	public List<Zones> getListOfZones() {
		return listOfZones;
	}


	public void setListOfZones(List<Zones> listOfZones) {
		this.listOfZones = listOfZones;
	}


	public String getOperatorName() {
		return operatorName;
	}


	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}


	public String getPassWord() {
		return passWord;
	}


	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}


	public String getAuthorized() {
		return authorized;
	}


	public void setAuthorized(String authorized) {
		this.authorized = authorized;
	}


	public Date getDateRegistered() {
		return dateRegistered;
	}


	public void setDateRegistered(Date dateRegistered) {
		this.dateRegistered = dateRegistered;
	}


	public String getZoneId() {
		return zoneId;
	}


	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}	

}
