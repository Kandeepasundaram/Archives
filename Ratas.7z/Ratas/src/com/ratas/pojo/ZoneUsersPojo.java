package com.ratas.pojo;

import java.util.List;

import com.ratas.dao.commons.Users;

public class ZoneUsersPojo {

	
	private String zoneName;
	private List<Users> listOfUsers;
	public String getZoneName() {
		return zoneName;
	}
	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}
	public List<Users> getListOfUsers() {
		return listOfUsers;
	}
	public void setListOfUsers(List<Users> listOfUsers) {
		this.listOfUsers = listOfUsers;
	}
	
}
