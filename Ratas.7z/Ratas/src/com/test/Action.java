package com.test;

import com.opensymphony.xwork2.ActionSupport;

public class Action extends ActionSupport
{
	
	private static final long serialVersionUID = 1L;
	String no1;
	String no2;
	public String getNo1() {
		return no1;
	}
	public void setNo1(String no1) {
		this.no1 = no1;
	}
	public String getNo2() {
		return no2;
	}
	public void setNo2(String no2) {
		this.no2 = no2;
	}
	public String execute() throws Exception
	{
		if(getNo1().equals("")||getNo2().equals(""))
			return ERROR;
		else
		{
			no2=Integer.toString(Integer.parseInt(no1)+Integer.parseInt(no2));
			return SUCCESS;
		}
	}
}
