package com.test;

import com.ratas.dblayer.base.DbRetriever;

public class Tester {
public static void main(String[] args) {
	String query;
	query = "select count(*) from zones";
		
	int count = DbRetriever.getInstance().getCount(query);
	System.out.println("" + count);
}
}
